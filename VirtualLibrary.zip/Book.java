package library;

import java.util.Comparator;

public class Book {

	// Attributes
	private String title;
	private String authorFirstName;
	private String authorLastName;
	private String genre;
	private String publisher;
	private int yearReleased;
	private int numberOfPages;;

	// Constructors
	public Book() {

		this.title = "";
		this.authorFirstName = "";
		this.authorLastName = "";
		this.genre = "";
		this.publisher = "";
		this.yearReleased = 0;
		this.numberOfPages = 0;
	}

	public Book(String title, String FN, String LN, String genre, String publisher, int YR, int NP) {

		this.title = title;
		this.authorFirstName = FN;
		this.authorLastName = LN;
		this.genre = genre;
		this.publisher = publisher;
		this.yearReleased = YR;
		this.numberOfPages = NP;
	}

	// Accessors
	public String getTitle() {
		return title;
	}

	public String getAuthorFirstName() {
		return authorFirstName;
	}

	public String getAuthorLastName() {
		return authorLastName;
	}

	public String getGenre() {
		return genre;
	}

	public String getPublisher() {
		return publisher;
	}

	public int getYearReleased() {
		return yearReleased;
	}

	public int getNumberOfPages() {
		return numberOfPages;
	}

	// Mutators
	public void setTitle(String title) {
		this.title = title;
	}

	public void setAuthorFirstName(String FN) {
		this.authorFirstName = FN;
	}

	public void setArthorLastName(String LN) {
		this.authorLastName = LN;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public void setYearReleased(int YR) {
		this.yearReleased = YR;
	}

	public void setNumberOfPages(int NP) {
		this.numberOfPages = NP;
	}
	
	public static Comparator<Book> BookTitleComparator = new Comparator<Book>() { //Makes the list go in ascending order

		public int compare(Book b1, Book b2) {
			String Book1 = b1.getTitle().toUpperCase();
			String Book2 = b2.getTitle().toUpperCase();

			return Book1.compareTo(Book2);
		}
	};

	public String toString() {
		String result;
		result = "Title: " + getTitle() + "\n";
		result += "Author's First Name: " + getAuthorFirstName() + "\n";
		result += "Author Last Name: " + getAuthorLastName() + "\n";
		result += "Genre: " + getGenre() + "\n";
		result += "Publisher: " + getPublisher() + "\n";
		result += "Year Released: " + getYearReleased() + "\n";
		result += "Number of Pages: " + getNumberOfPages();

		return result;
	}
	
	public String toCSV() {
		String result;
		result = title + ",";
		result += authorFirstName + ",";
		result += authorLastName + ",";
		result += genre + ",";
		result += publisher + ",";
		result += yearReleased + ",";
		result += numberOfPages;
		
		
		return result;
	}

}
