package library;

import javax.swing.JOptionPane;

public class InputConfirm {

	public static String getString(String promt, String title) {

		String result = "";

		result = JOptionPane.showInputDialog(null, promt, title, JOptionPane.QUESTION_MESSAGE);

		return result;
	}

	public static int getInt(String promt, String title, String errorMessage) {

		boolean invalid;
		String input = "";
		int result = 0;

		do {
			invalid = false;
			try {
				input = JOptionPane.showInputDialog(null, promt, title, JOptionPane.QUESTION_MESSAGE);
				if (input.length() == 0)
					throw new Exception("Input is Blank");
				result = Integer.parseInt(input);
			} catch (Exception e) {
				invalid = true;
				JOptionPane.showMessageDialog(null, e.getMessage() + "\n" + errorMessage, "ERROR",
						JOptionPane.ERROR_MESSAGE);
			}

		} while (invalid);

		return result;

	}

}
