package library;

import javax.swing.JOptionPane;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class LibraryApplication {

	private static ArrayList<Book> Library = new ArrayList<>();
	public static int bookCount = 0;

	public static void main(String[] args) throws IOException {

		showSplashScreen();
		menuChoice();

	} // Ends Main

	public static void showSplashScreen() {
		JOptionPane.showMessageDialog(null,
				"Welcome to the Virtual Library" + "\nYou will be able to enter, save, and track all the books you own",
				"Intro Screen", JOptionPane.INFORMATION_MESSAGE);
	}

	public static void menuChoice() throws IOException {

		boolean fileMod = false;
		String menuChoice;

		String[] menuChoices = { "Select Option", "1 - Add a Book to List", "2 - Display Input on List",
				"3 - Save List to File", "4 - Read List from File", "Exit Application" };
		do {
			menuChoice = (String) JOptionPane.showInputDialog(null, "Select Option", "Main Menuu",
					JOptionPane.PLAIN_MESSAGE, null, menuChoices, menuChoices[0]);

			if (menuChoice.equals(menuChoices[1])) {
				do {
					enterInfo();
					fileMod = true;
				} while (JOptionPane.showConfirmDialog(null, "Do You Want to Enter Anther Entry", "Entry",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION);

			} else if (menuChoice.equals(menuChoices[2])) { // Reads the data on the list
				printArrayList();

			} else if (menuChoice.equals(menuChoices[3])) { // Saves the data to a file

				saveList(Library, null);
				fileMod = false;

			} else if (menuChoice.equals(menuChoices[4])) { // Enter a file name and reads what is on that file and the
															// file location

				readList();
				fileMod = false;
			}

		} while ((!menuChoice.equals(menuChoices[menuChoices.length - 1]))); // Closes the application

		if (fileMod && JOptionPane.showConfirmDialog(null, "List is modified. Do you want to save it", "Save Books",
				JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
			saveList(Library, null);
		}
		JOptionPane.showMessageDialog(null, "Thank You for Using the Virtual Library");
	}

	public static void enterInfo() throws IOException {

		String title;
		String authorFirstName;
		String authorLastName;
		String genre;
		String publisher;
		int yearReleased;
		int numberOfPages;

		bookCount++;

		title = InputConfirm.getString("Enter Title of Book", "Book #" + bookCount + " - Title");
		authorFirstName = InputConfirm.getString("Enter " + title + "'s Author's first name", "Authors First Name");
		authorLastName = InputConfirm.getString("Enter " + title + "'s Author's last name", "Author's last name");
		genre = InputConfirm.getString("Enter " + title + "'s genre", "Book's Genre");
		publisher = InputConfirm.getString("Enter " + title + "'s publisher", "Book's Publisher");
		yearReleased = InputConfirm.getInt("Enter " + title + "'s year of released", "Book's Released Year",
				"Enter an Integer");
		numberOfPages = InputConfirm.getInt("Enter " + title + "'s number of pages it has", "Book's number of pages",
				"Enter an Integer");

		Library.add(new Book(title, authorFirstName, authorLastName, genre, publisher, yearReleased, numberOfPages));
		Collections.sort(Library, Book.BookTitleComparator);

	}

	private static void printArrayList() {

		for (int i = 0; i < Library.size(); i++) {
			JOptionPane.showMessageDialog(null, Library.get(i), "Book: " + Library.get(i).getTitle(),
					JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public static void saveList(ArrayList<Book> Library, String fileName) throws IOException {

		File file;
		fileName = JOptionPane.showInputDialog("What is the file name you wish to create");
		file = new File(fileName + ".csv");

		String appendInput = JOptionPane.showInputDialog(null, "Do you want to Append or Overwrite " + "(A or O)");
		boolean append = (appendInput.toLowerCase().charAt(0) == 'a' ? true : false);

		FileWriter fW = new FileWriter(file, append);
		PrintWriter pW = new PrintWriter(fW);
		if (!append) {
			pW.println("Title" + "," + "Author First Name" + "," + "Author Last Name" + "," + "Genre" + ","
					+ "Publisher" + "," + " Year Released" + "," + "Number of Pages\n");
		}
		for (int i = 0; i < Library.size(); i++) {

			pW.println(Library.get(i).toCSV());
		}
		JOptionPane.showMessageDialog(null, "You saved a file at " + file.getAbsolutePath());

		Library.clear();
		pW.close();

	}

	public static File readList() throws IOException {

		String fileName;
		File file;

		do {
			fileName = JOptionPane.showInputDialog("What is the file you wish to open");
			file = new File(fileName + ".csv");
			if (!file.exists()) {
				JOptionPane.showMessageDialog(null, "File " + fileName + " does not exist.\nEnter a new file name.",
						"File Not Found Error", JOptionPane.ERROR_MESSAGE);
			}
		} while (!file.exists());
		@SuppressWarnings("resource")
		BufferedReader bR = new BufferedReader(new FileReader(file));
		bR.readLine(); // Skips the first line
		bR.readLine(); // Skips the second line
		JOptionPane.showMessageDialog(null, "You Opened File at " + file.getAbsolutePath());
		JOptionPane.showMessageDialog(null, "Data displayed in CSV() format" + 
		"\nTitle,Author First Name,Author Last Name,Genre,Publisher,Year Released,Number of Pages");
		while ((fileName = bR.readLine()) != null) {
			JOptionPane.showMessageDialog(null, fileName);
		}
		return file;
	}

}